# Inleveropdracht 1 netwerken en security vervolg
**Ivo Bruinsma**\
**1082102**

## Set-up
Alles wat nodig is om deze chat applicatie op te zetten is om docker draaiende te hebben & de bestanden gedownload the hebben.\
Het enige wat je hoeft te doen is het command ```docker-compose up ``` in de terminal te runnen. Dit wel in een terminal die zich in de zelfde folder als het ```docker-compose.yml``` bevindt.

## Gebruik
Om de chat application te gebruiken moet je in de browser naar localhost te gaan.\
Er zal ingelogd moeten worden. Dit kan gedaan worden met de volgende gebruikers:\
| Gebruikersnaam|Wachtwoord               
|---------------|-------------------------
|Tom            |Partytent                
|Adela          |JanSmitFan1234           
|Kai            |BetaalNietTeVeelVoorHotel
|Bradge         |2EuroFooi
|Roy            |C4IsMyBiggestHater
|Mauri          |HorseFighter